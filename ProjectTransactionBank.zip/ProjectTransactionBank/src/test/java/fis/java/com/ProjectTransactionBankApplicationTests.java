package fis.java.com;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectTransactionBankApplicationTests {

	@Test
	void contextLoads() {
	}

}
