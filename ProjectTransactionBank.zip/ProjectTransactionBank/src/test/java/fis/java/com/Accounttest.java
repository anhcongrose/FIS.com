package fis.java.com;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;

import fis.java.com.DTO.ResponseDTO;
import fis.java.com.Entity.Account;
import fis.java.com.Repository.AccountRepository;
import fis.java.com.Repository.CustomerRepository;
import fis.java.com.Service.IAccountService;

public class Accounttest {
	@InjectMocks
	IAccountService accountService;

	@Mock
	AccountRepository accountRepo;

	@Mock
	CustomerRepository customerRepo;

	@Test
	void createAccount() {
		Account account = new Account((long) 1, "122222222", 10000.0, 1);
		Mockito.when(accountRepo.save(account)).thenReturn(account);
		Mockito.when(accountRepo.findByAccountNumber("122222222")).thenReturn(null);
		ResponseDTO kq = accountService.createAccount(account);
		assertThat(kq);
	}

	@Test
	void updateAccount() {
		List<Account> listaccount = new ArrayList<>();
		Account account = new Account((long) 2, "12333333", 1000.0, 1);
		listaccount.add(account);
		Mockito.when(accountRepo.save(account)).thenReturn(account);
		Mockito.when(accountRepo.findById(account.getAccountId())).thenReturn(null);
		ResponseDTO kq = accountService.updateAccount(account);
		assertThat(kq);
		assertThat("updatate succes!");

	}
}
