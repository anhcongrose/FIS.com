package fis.java.com.Entity;

public enum CustomerType {
	INDIVIDUAL, CORPORATE

}
