package fis.java.com.Repository;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import fis.java.com.DTO.TransactionDTO;
import fis.java.com.Entity.Transaction;

@Repository
public interface TransactionReposiory extends JpaRepository<Transaction, Long> {

	void save(TransactionDTO transaction);

	List<Transaction> findAllByOrderByTransactionDateDesc();

//	@Modifying
//	@Query(value = "SELECT tracsaction_Id, transaction_Date FROM Transaction a "
//			+ "WHERE a.startDate 1? and ?2 ODER BY a.transactionDate DESC", nativeQuery = true)
//	List<Transaction> getListtransaction();
//	
	@Query("SELECT u FROM Transaction u WHERE u.transactionDate between ?1 and  ?2 ORDER BY u.transactionDate DESC")
	List<Transaction> listTransaction(LocalDateTime from, LocalDateTime to);

}
