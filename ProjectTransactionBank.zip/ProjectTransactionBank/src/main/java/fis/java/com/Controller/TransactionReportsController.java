package fis.java.com.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import fis.java.com.Entity.Transaction;
import fis.java.com.Service.ITransactionReportsServicer;

@RestController
@RequestMapping(value = "/transactionreport")
public class TransactionReportsController {
	@Autowired
	private ITransactionReportsServicer service;

	@GetMapping(value = "/report")
	public List<Transaction> getTransaction(@RequestParam(defaultValue = "empty") String from,
			@RequestParam(defaultValue = "empty") String to) {

		return service.listTransactionReportByTime(from, to);

	}
}
