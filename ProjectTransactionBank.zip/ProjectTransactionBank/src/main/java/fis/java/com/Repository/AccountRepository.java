package fis.java.com.Repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import fis.java.com.Entity.Account;

@Repository
public interface AccountRepository extends JpaRepository<Account, Long> {
// tìm kiếm Account theo số tài khoản
	Account findByAccountNumber(String accountNumber);

	// kiểm tra Account đã tồn tại chưa vs AccountNumber là duy nhất!
	boolean existsByAccountNumber(String accountNumber);

	// lấy ra danh sách Account theo customerId truyền vào!
	List<Account> findAllByCustomer(Long customerId);

	// lấy ra danh sách Account và sắp xếp theo điều kiện!
	@Query("SELECT e FROM Account e")
	List<Account> findAll(Sort sort);

	// lấy ra tất cả các Account và phân trang
	@Query(value = "SELECT * FROM Account account", nativeQuery = true)
	Page<Account> getAllAccount(Pageable pageable);

	// lấy ra danh sách account còn hiệu lực theo customer truyền vào!
	@Query(value = "SELECT account FROM Account account WHERE " + "account.status=1"
			+ "ORDER BY accountNumber", nativeQuery = true)
	List<Account> findAllAccountOderbyAccountNumberHieuLuc(Long customerId);

	// lấy ra danh sách account hết hiệu lực theo customerId truyền vào!
	@Query(value = "SELECT account FROM Account account WHERE " + "account.status !=1"
			+ "ORDER BY accountNumber", nativeQuery = true)
	List<Account> getAllAccountOderbyAccountNumberNoHieuLuc(Long customerId);

	// Tìm kiếm tất cả danh sách account theo khách hàng.
	// Sắp xếp theo trạng thái (hiệu lực hiển thị trước) và số tài khoản.

	@Query("SELECT e FROM Account e ORDER BY e.status DESC")
	List<Account> findAllAccountOderbystatus(Long customerId);

	
}
