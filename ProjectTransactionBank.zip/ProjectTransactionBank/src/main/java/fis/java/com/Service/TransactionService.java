package fis.java.com.Service;

import java.time.LocalDateTime;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fis.java.com.Constant.Constant;
import fis.java.com.DTO.TransactionDTO;
import fis.java.com.Entity.Account;
import fis.java.com.Entity.Transaction;
import fis.java.com.Repository.AccountRepository;
import fis.java.com.Repository.TransactionReposiory;

@Service
@Transactional
public class TransactionService implements ITransactionService {

	@Autowired
	private TransactionReposiory repository;

	@Autowired
	private AccountRepository accRepo;

	@Override
	public void deleteTransactionById(Long id) {

		repository.deleteById(id);
	}

	@Override
	public List<Transaction> listTransaction(String from, String to) {
//convert String to LocalDateTime!
		LocalDateTime localDatefrom = null;
		LocalDateTime localDateto = null;
		if (from != null && !from.isEmpty()) {
			String[] listdate = from.split("-");

			localDatefrom = LocalDateTime.of(Integer.parseInt(listdate[2]), Integer.parseInt(listdate[1]),
					Integer.parseInt(listdate[0]), 0, 0);
		}
		if (to != null && !to.isEmpty()) {
			String[] listdate = to.split("-");

			localDateto = LocalDateTime.of(Integer.parseInt(listdate[2]), Integer.parseInt(listdate[1]),
					Integer.parseInt(listdate[0]), 0, 0);
		}
		return repository.listTransaction(localDatefrom, localDateto);
	}

	@Override
	public List<Transaction> findAllByOrderByTransactionDateDesc(String accountNumber) {
		// truyền vào accountNumbercần tìm kiếm
		String message = "";
		try {
			if (!accRepo.existsByAccountNumber(accountNumber)) {

				message += "accountNumber not exists!";
			} else {
				Transaction transaction = null;
				transaction.setTransactionDate(transaction.getTransactionDate());

				repository.findAllByOrderByTransactionDateDesc();
			}
		} catch (Exception e) {
			message += e.getMessage();
		}

		return null;
	}

	@Override
	public Transaction CreatebankMoney(TransactionDTO formtransaction) {

		Account fromAccount = accRepo.findById(formtransaction.getFromAccount()).orElse(null);
		Account toAccount = accRepo.findById(formtransaction.getToAccount()).orElse(null);

		Transaction transaction = new Transaction();

		transaction.setAmount(formtransaction.getAmount());
		transaction.setContent(formtransaction.getContent());
		transaction.setFromAccount(fromAccount);
		transaction.setToAccuont(toAccount);
//
		if (fromAccount.getStatus() == Constant.ACCOUNT_STATUS_HET_HIEU_LUC
				|| toAccount.getStatus() == Constant.ACCOUNT_STATUS_HET_HIEU_LUC) {
			transaction.setErrorReason("Error:fromAccount or toAccount is expire, please checked!");
			transaction.setStatus(Constant.ACCOUNT_STATUS_HET_HIEU_LUC);
		}
		if (fromAccount.getBalance() < (formtransaction.getToAccount())) {
			transaction.setErrorReason("fromAccount insufficient balance! plesae recharge monney!");
			transaction.setStatus(Constant.TRANSACTION_STATUS_FAIL);
		}
		fromAccount.setBalance(fromAccount.getBalance() - formtransaction.getAmount());
		toAccount.setBalance(toAccount.getBalance() + formtransaction.getAmount());
		transaction.setErrorReason("SUCCESS");
		transaction.setStatus(Constant.TRANSACTION_STATUS_SUCCESS);
		return repository.save(transaction);
	}

}
