package fis.java.com.DTO;

import java.time.LocalDate;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
@AllArgsConstructor
@Getter
@Setter

public class TransactionDTO {
	@NotBlank(message = "")
	private LocalDate transactionDate=LocalDate.now();
	@NotBlank
	private Long fromAccount;
	@NotBlank
	private Long toAccount;
	@NotBlank
	// Số tiền thực hiện chuyển khoản
	private Double amount;
	private int status;
// Nội dung thực hiện giao dịch
//	@Length(max =50,min = 15, message = "nội dung giao dịch không vượt quá 50 ký tự!")
	private String content;
// Lý do giao dịch lỗi ví dụ: Số dư tài khoản không đủ, tài khoản nhận
//	tiền không tồn tại hoặc tạm 	khoá.	
	private String errorReason;

}
