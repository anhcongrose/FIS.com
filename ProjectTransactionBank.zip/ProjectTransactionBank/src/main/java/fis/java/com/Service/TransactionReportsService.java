package fis.java.com.Service;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fis.java.com.Entity.Transaction;
import fis.java.com.Exception.AppException;
import fis.java.com.Repository.TransactionReposiory;
@Service
public class TransactionReportsService implements ITransactionReportsServicer {

	@Autowired
	private TransactionReposiory repository;

	@Override
	public List<Transaction> listTransactionReportByTime(String from, String to) {

		// convert String to LocalDateTime!
		LocalDateTime localDatefrom = null;
		LocalDateTime localDateto = null;
		if (from != null && !from.isEmpty()) {
			String[] listdate = from.split("-");

			localDatefrom = LocalDateTime.of(Integer.parseInt(listdate[2]), Integer.parseInt(listdate[1]),
					Integer.parseInt(listdate[0]), 0, 0);
		}
		if (to != null && !to.isEmpty()) {
			String[] listdate = to.split("-");

			localDateto = LocalDateTime.of(Integer.parseInt(listdate[2]), Integer.parseInt(listdate[1]),
					Integer.parseInt(listdate[0]), 0, 0);
		}
		long daysBetween = ChronoUnit.DAYS.between(localDatefrom, localDateto);
		if (daysBetween > 60)
			throw new AppException("Error", "Longtime is tolong");
		return repository.listTransaction(localDatefrom, localDateto);

	}

}
