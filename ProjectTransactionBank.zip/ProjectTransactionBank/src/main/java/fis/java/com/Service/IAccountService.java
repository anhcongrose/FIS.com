package fis.java.com.Service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import fis.java.com.DTO.ResponseDTO;
import fis.java.com.Entity.Account;

public interface IAccountService {

	Account findByAccountNumber(String accountNumber);

	List<Account> getAllAccounts();

	List<Account> findAllByCustomer(Long customerId);

//	List<Account> findAll(Sort sort);

	Page<Account> getAllAccounts(Pageable pageable);

	List<Account> findAllAccountOderbyAccountNumberHieuLuc(Long customerId);

	List<Account> getAllAccountOderbyAccountNumberNoHieuLuc(Long customerId);

	ResponseDTO createAccount(Account account);

	ResponseDTO updateAccount(Account account);

	void deleteById(Long Id);

	Account getAccountById(Long id);

	List<Account> findAllAccountOderbystatus(Long customerId);
}
