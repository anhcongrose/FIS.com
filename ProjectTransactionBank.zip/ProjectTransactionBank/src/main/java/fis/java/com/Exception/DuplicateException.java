package fis.java.com.Exception;

import javax.validation.ValidationException;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DuplicateException extends ValidationException {

	private static final long serialVersionUID = 1L;
	private String code;
	private String message;

}
