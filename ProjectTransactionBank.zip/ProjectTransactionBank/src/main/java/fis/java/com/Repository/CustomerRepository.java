package fis.java.com.Repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import fis.java.com.Entity.Customer;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long>, JpaSpecificationExecutor<Customer> {

	boolean existsByCustomerName(String customerName);

	boolean existsByIdentityNo(String identityNo);

	Customer findByCustomerName(String customerNumber);

	List<Customer> findAllByOrderByCustomerNameDesc();

	@Query("SELECT e FROM Customer e")
	Page<Customer> findCustomers(Pageable pageable, List<Customer> customerList);

}
