package fis.java.com.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import fis.java.com.DTO.TransactionDTO;
import fis.java.com.Entity.Transaction;
import fis.java.com.Service.ITransactionService;

@RestController
@RequestMapping(value = "/transaction")
public class TransactionController {
	@Autowired
	private ITransactionService service;

//	@GetMapping(value = "/{id}")
//	public ResponseEntity<?> listTransaction(@PathVariable(name = "id") LocalDate from,LocalDate to ) {
//
//		return new ResponseEntity<>(service.listTransaction(from, to), HttpStatus.OK);
//	}
	@GetMapping(value = "/")
	public List<Transaction> getTransaction(@RequestParam(defaultValue = "empty") String from,
			@RequestParam(defaultValue = "empty") String to) {

		return service.listTransaction(from, to);

	}

	@PostMapping()
	public ResponseEntity<?> createTransaction(@RequestBody TransactionDTO transaction) {

		return ResponseEntity.ok(service.CreatebankMoney(transaction));
	}

}
