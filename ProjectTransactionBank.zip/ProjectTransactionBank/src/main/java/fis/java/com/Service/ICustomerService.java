package fis.java.com.Service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import fis.java.com.DTO.ResponseDTO;
import fis.java.com.Entity.Customer;

public interface ICustomerService {

	List<Customer> getAllCustomers();
	
	Page<Customer> findCustomers(Pageable pageable, List<Customer> customerList);
	
	void deleteById(Long Id);

	Customer getCustomerById(Long id);

	ResponseDTO updateCustomer(Customer customer);

	ResponseDTO createCustomer(Customer customer);

	
}
