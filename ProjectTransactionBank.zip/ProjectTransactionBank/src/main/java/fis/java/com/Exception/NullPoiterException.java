package fis.java.com.Exception;

public class NullPoiterException extends AppException {

	private static final long serialVersionUID = 1L;

	public NullPoiterException(String message) {
		super(message, message);

	}

}
