package fis.java.com.Constant;

public final class Constant {

	public static final int ACCOUNT_STATUS_HET_HIEU_LUC = 0;
	public static final int ACCOUNT_STATUS_HIEU_LUC = 1;
	public static final int ACCOUNT_STATUS_TAM_KHOA = 2;
	public static final int TRANSACTION_STATUS_FAIL = 0;
	public static final int TRANSACTION_STATUS_SUCCESS = 1;
	public static final double ACCOUNT_START_BALANCE = 100000;

}
