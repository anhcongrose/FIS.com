package fis.java.com.Service;

import java.util.List;

import fis.java.com.Entity.Transaction;

public interface ITransactionReportsServicer {

	//seach listTransaction in tolong time 60day!
	List<Transaction> listTransactionReportByTime(String from, String to);

}
