package fis.java.com.Service;

import java.util.List;

import fis.java.com.DTO.TransactionDTO;
import fis.java.com.Entity.Transaction;

public interface ITransactionService {

	void deleteTransactionById(Long id);

	Transaction CreatebankMoney(TransactionDTO formtransaction);

	// get transaction from by customerid and oderby transactiondate DESC;
	List<Transaction> findAllByOrderByTransactionDateDesc(String accountNumber);

	// get transaction from by customerId and oder transactiondate DESC in timeOut;
	List<Transaction> listTransaction(String from, String to);

}
